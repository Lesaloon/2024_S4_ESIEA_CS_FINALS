export enum DifficultyLevel {
	EASY = "EASY",
	MEDIUM = "MEDIUM",
	HARD = "HARD"
}