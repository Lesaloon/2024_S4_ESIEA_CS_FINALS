export interface Step {
	id: number;
	title: string;
	sequenceNumber: number;
	description: string;
	photo: string; // une représentation en base64
}
