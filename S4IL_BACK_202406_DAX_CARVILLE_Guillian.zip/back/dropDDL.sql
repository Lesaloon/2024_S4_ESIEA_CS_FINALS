ALTER TABLE material DROP FOREIGN KEY FK_material_tutorial_id
ALTER TABLE step DROP FOREIGN KEY FK_step_tutorial_id
DROP TABLE material
DROP TABLE tutorial
DROP TABLE step
