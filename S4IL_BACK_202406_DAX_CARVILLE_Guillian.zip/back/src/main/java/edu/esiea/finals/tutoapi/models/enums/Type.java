package edu.esiea.finals.tutoapi.models.enums;

public enum Type {
	COOKING, DIY, ARTS_AND_CRAFTS;
}
