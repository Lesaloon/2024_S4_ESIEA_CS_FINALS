package edu.esiea.finals.tutoapi.models.enums;

public enum DifficultyLevel {
	EASY, MEDIUM, HARD;
}
